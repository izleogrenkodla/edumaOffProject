<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit();
}
?>
<ul class="event-auth-notice error">
    <li><?php _e( 'Oops! Something went wrong.' ) ?></li>
</ul>